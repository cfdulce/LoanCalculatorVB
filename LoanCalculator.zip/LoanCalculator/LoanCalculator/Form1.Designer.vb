﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        vehicleLoanInfo = New GroupBox()
        txtMonths = New TextBox()
        txtDownPayment = New TextBox()
        txtCostOfVehicle = New TextBox()
        Label3 = New Label()
        Label2 = New Label()
        vehicleCost = New Label()
        newOrUsed = New GroupBox()
        radUsed = New RadioButton()
        radNew = New RadioButton()
        interestAndPrincipalPayments = New GroupBox()
        txtAnnualRate = New TextBox()
        lblAnnualRate = New Label()
        lstPaymentsInfo = New ListBox()
        btnCalculate = New Button()
        btnClear = New Button()
        btnExit = New Button()
        vehicleLoanInfo.SuspendLayout()
        newOrUsed.SuspendLayout()
        interestAndPrincipalPayments.SuspendLayout()
        SuspendLayout()
        ' 
        ' vehicleLoanInfo
        ' 
        vehicleLoanInfo.Controls.Add(txtMonths)
        vehicleLoanInfo.Controls.Add(txtDownPayment)
        vehicleLoanInfo.Controls.Add(txtCostOfVehicle)
        vehicleLoanInfo.Controls.Add(Label3)
        vehicleLoanInfo.Controls.Add(Label2)
        vehicleLoanInfo.Controls.Add(vehicleCost)
        vehicleLoanInfo.Location = New Point(86, 46)
        vehicleLoanInfo.Margin = New Padding(2, 3, 2, 3)
        vehicleLoanInfo.Name = "vehicleLoanInfo"
        vehicleLoanInfo.Padding = New Padding(2, 3, 2, 3)
        vehicleLoanInfo.Size = New Size(643, 258)
        vehicleLoanInfo.TabIndex = 0
        vehicleLoanInfo.TabStop = False
        vehicleLoanInfo.Text = "Vehicle & Loan Information"
        ' 
        ' txtMonths
        ' 
        txtMonths.Location = New Point(467, 183)
        txtMonths.Margin = New Padding(2, 3, 2, 3)
        txtMonths.Name = "txtMonths"
        txtMonths.Size = New Size(81, 39)
        txtMonths.TabIndex = 6
        ' 
        ' txtDownPayment
        ' 
        txtDownPayment.Location = New Point(467, 109)
        txtDownPayment.Margin = New Padding(2, 3, 2, 3)
        txtDownPayment.Name = "txtDownPayment"
        txtDownPayment.Size = New Size(81, 39)
        txtDownPayment.TabIndex = 5
        ' 
        ' txtCostOfVehicle
        ' 
        txtCostOfVehicle.Location = New Point(467, 46)
        txtCostOfVehicle.Margin = New Padding(2, 3, 2, 3)
        txtCostOfVehicle.Name = "txtCostOfVehicle"
        txtCostOfVehicle.Size = New Size(81, 39)
        txtCostOfVehicle.TabIndex = 4
        ' 
        ' Label3
        ' 
        Label3.Location = New Point(29, 186)
        Label3.Margin = New Padding(2, 0, 2, 0)
        Label3.Name = "Label3"
        Label3.Size = New Size(302, 46)
        Label3.TabIndex = 2
        Label3.Text = "Number of Months"
        ' 
        ' Label2
        ' 
        Label2.Location = New Point(29, 109)
        Label2.Margin = New Padding(2, 0, 2, 0)
        Label2.Name = "Label2"
        Label2.Size = New Size(391, 56)
        Label2.TabIndex = 1
        Label2.Text = "Amount of Down Payment"
        ' 
        ' vehicleCost
        ' 
        vehicleCost.AutoSize = True
        vehicleCost.Location = New Point(29, 53)
        vehicleCost.Margin = New Padding(2, 0, 2, 0)
        vehicleCost.Name = "vehicleCost"
        vehicleCost.Size = New Size(221, 32)
        vehicleCost.TabIndex = 0
        vehicleCost.Text = "Cost of Vehicle"
        ' 
        ' newOrUsed
        ' 
        newOrUsed.Controls.Add(radUsed)
        newOrUsed.Controls.Add(radNew)
        newOrUsed.Location = New Point(964, 46)
        newOrUsed.Margin = New Padding(2, 3, 2, 3)
        newOrUsed.Name = "newOrUsed"
        newOrUsed.Padding = New Padding(2, 3, 2, 3)
        newOrUsed.Size = New Size(346, 211)
        newOrUsed.TabIndex = 1
        newOrUsed.TabStop = False
        newOrUsed.Text = "New or Used?"
        ' 
        ' radUsed
        ' 
        radUsed.AutoSize = True
        radUsed.Location = New Point(111, 129)
        radUsed.Margin = New Padding(2, 3, 2, 3)
        radUsed.Name = "radUsed"
        radUsed.Size = New Size(112, 36)
        radUsed.TabIndex = 1
        radUsed.TabStop = True
        radUsed.Text = "Used"
        radUsed.UseVisualStyleBackColor = True
        ' 
        ' radNew
        ' 
        radNew.AutoSize = True
        radNew.Location = New Point(111, 49)
        radNew.Margin = New Padding(2, 3, 2, 3)
        radNew.Name = "radNew"
        radNew.Size = New Size(102, 36)
        radNew.TabIndex = 0
        radNew.TabStop = True
        radNew.Text = "New"
        radNew.UseVisualStyleBackColor = True
        ' 
        ' interestAndPrincipalPayments
        ' 
        interestAndPrincipalPayments.Controls.Add(txtAnnualRate)
        interestAndPrincipalPayments.Controls.Add(lblAnnualRate)
        interestAndPrincipalPayments.Controls.Add(lstPaymentsInfo)
        interestAndPrincipalPayments.Location = New Point(86, 351)
        interestAndPrincipalPayments.Margin = New Padding(2, 3, 2, 3)
        interestAndPrincipalPayments.Name = "interestAndPrincipalPayments"
        interestAndPrincipalPayments.Padding = New Padding(2, 3, 2, 3)
        interestAndPrincipalPayments.Size = New Size(1224, 308)
        interestAndPrincipalPayments.TabIndex = 2
        interestAndPrincipalPayments.TabStop = False
        interestAndPrincipalPayments.Text = "Interest and Principal Payments"
        ' 
        ' txtAnnualRate
        ' 
        txtAnnualRate.Location = New Point(931, 42)
        txtAnnualRate.Margin = New Padding(2, 3, 2, 3)
        txtAnnualRate.Name = "txtAnnualRate"
        txtAnnualRate.Size = New Size(160, 39)
        txtAnnualRate.TabIndex = 2
        ' 
        ' lblAnnualRate
        ' 
        lblAnnualRate.AutoSize = True
        lblAnnualRate.Location = New Point(596, 49)
        lblAnnualRate.Margin = New Padding(2, 0, 2, 0)
        lblAnnualRate.Name = "lblAnnualRate"
        lblAnnualRate.Size = New Size(293, 32)
        lblAnnualRate.TabIndex = 1
        lblAnnualRate.Text = "Annual Interest Rate"
        ' 
        ' lstPaymentsInfo
        ' 
        lstPaymentsInfo.FormattingEnabled = True
        lstPaymentsInfo.ItemHeight = 32
        lstPaymentsInfo.Location = New Point(88, 96)
        lstPaymentsInfo.Margin = New Padding(2, 3, 2, 3)
        lstPaymentsInfo.Name = "lstPaymentsInfo"
        lstPaymentsInfo.Size = New Size(1044, 164)
        lstPaymentsInfo.TabIndex = 0
        ' 
        ' btnCalculate
        ' 
        btnCalculate.Location = New Point(347, 714)
        btnCalculate.Margin = New Padding(2, 3, 2, 3)
        btnCalculate.Name = "btnCalculate"
        btnCalculate.Size = New Size(187, 49)
        btnCalculate.TabIndex = 3
        btnCalculate.Text = "Calculate"
        btnCalculate.UseVisualStyleBackColor = True
        ' 
        ' btnClear
        ' 
        btnClear.Location = New Point(636, 714)
        btnClear.Margin = New Padding(2, 3, 2, 3)
        btnClear.Name = "btnClear"
        btnClear.Size = New Size(187, 49)
        btnClear.TabIndex = 4
        btnClear.Text = "Clear"
        btnClear.UseVisualStyleBackColor = True
        ' 
        ' btnExit
        ' 
        btnExit.Location = New Point(964, 714)
        btnExit.Margin = New Padding(2, 3, 2, 3)
        btnExit.Name = "btnExit"
        btnExit.Size = New Size(187, 49)
        btnExit.TabIndex = 5
        btnExit.Text = "Exit"
        btnExit.UseVisualStyleBackColor = True
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(17F, 32F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.AliceBlue
        ClientSize = New Size(1565, 813)
        Controls.Add(btnExit)
        Controls.Add(btnClear)
        Controls.Add(btnCalculate)
        Controls.Add(interestAndPrincipalPayments)
        Controls.Add(newOrUsed)
        Controls.Add(vehicleLoanInfo)
        Font = New Font("Lucida Fax", 10F, FontStyle.Regular, GraphicsUnit.Point)
        Name = "Form1"
        Text = "Loan Calculator"
        vehicleLoanInfo.ResumeLayout(False)
        vehicleLoanInfo.PerformLayout()
        newOrUsed.ResumeLayout(False)
        newOrUsed.PerformLayout()
        interestAndPrincipalPayments.ResumeLayout(False)
        interestAndPrincipalPayments.PerformLayout()
        ResumeLayout(False)
    End Sub

    Friend WithEvents vehicleLoanInfo As GroupBox
    Friend WithEvents txtMonths As TextBox
    Friend WithEvents txtDownPayment As TextBox
    Friend WithEvents txtCostOfVehicle As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents vehicleCost As Label
    Friend WithEvents newOrUsed As GroupBox
    Friend WithEvents radUsed As RadioButton
    Friend WithEvents radNew As RadioButton
    Friend WithEvents interestAndPrincipalPayments As GroupBox
    Friend WithEvents txtAnnualRate As TextBox
    Friend WithEvents lblAnnualRate As Label
    Friend WithEvents lstPaymentsInfo As ListBox
    Friend WithEvents btnCalculate As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents btnExit As Button
End Class
