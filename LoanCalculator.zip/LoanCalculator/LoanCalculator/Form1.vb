﻿Public Class Form1

    Const MONTHS_YEAR As Double = 12     ' Months per year
    Const NEW_RATE As Double = 0.089     ' Interest rate, new cars
    Const USED_RATE As Double = 0.095    ' Interest rate, used cars

    Private Sub btnClear_Click() Handles btnClear.Click
        ' Clear the TextBoxes and the Label
        txtCostOfVehicle.Clear()
        txtDownPayment.Clear()
        txtMonths.Clear()
        txtAnnualRate.Clear()
        lstPaymentsInfo.Text = String.Empty

    End Sub

    Private Sub btnExit_Click() Handles btnExit.Click
        ' Close the form.
        Me.Close()
    End Sub

    Dim dblAnnualRate As Double

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click

        Dim vehicleCost As Double    ' Vehicle cost
        Dim downPayment As Double    ' Down payment
        Dim months As Integer        ' Number of months for the loan
        Dim dblLoan As Double           ' Amount of the loan
        Dim dblMonthlyPayment As Double ' Monthly payment
        Dim dblInterest As Double       ' Interest paid for the period
        Dim dblPrincipal As Double      ' Principal paid for the period
        Dim intCount As Integer         ' Counter for the loop
        Dim strOut As String            ' Used to hold a line of output
        Dim blnInputOk As Boolean = True

        ' Get the vehicle cost, validating at the same time.–
        If Not Double.TryParse(txtCostOfVehicle.Text, vehicleCost) Then
            txtCostOfVehicle.Text = "Vehicle cost must be a number"
            blnInputOk = False
        End If

        ' Get the down payment, validating at the same time.
        If Not Double.TryParse(txtDownPayment.Text, downPayment) Then
            txtDownPayment.Text = "Down Payment must be a number"
            blnInputOk = False
        End If

        ' Get the number of months, validating at the same time.
        If Not Integer.TryParse(txtMonths.Text, months) Then
            txtMonths.Text = "Months must be an integer"
            blnInputOk = False
        End If

        If blnInputOk = True Then
            ' Calculate the loan amount and monthly payment.
            dblLoan = vehicleCost - downPayment
            dblMonthlyPayment = Pmt(dblAnnualRate / MONTHS_YEAR, months, -dblLoan)

            ' Clear the list box and message label.
            lstPaymentsInfo.Items.Clear()

            For intCount = 1 To months
                ' Calculate the interest for this period.
                dblInterest = IPmt(dblAnnualRate / MONTHS_YEAR, intCount, months, -dblLoan)
                ' Calculate the principal for this period.
                dblPrincipal = PPmt(dblAnnualRate / MONTHS_YEAR, intCount, months, -dblLoan)
                ' Start building the output string with the month.
                strOut = "Month " & intCount.ToString("d2")
                ' Add the payment amount to the output string
                strOut &= ": payment = " & dblMonthlyPayment.ToString("n2")
                ' Add the interest amount to the output string.
                strOut &= ", interest = " & dblInterest.ToString("n2")
                ' Add the principal for the period.
                strOut &= ", principal = " & dblPrincipal.ToString("n2")
                ' Add the output string to the list box
                lstPaymentsInfo.Items.Add(strOut)
            Next
        End If
    End Sub

    Private Sub radNew_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles radNew.CheckedChanged
        ' If the New radio button is checked, then
        ' the user has selected a new car loan.
        If radNew.Checked = True Then
            dblAnnualRate = NEW_RATE
            txtAnnualRate.Text = NEW_RATE.ToString("p")
        End If
    End Sub

    Private Sub radUsed_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles radUsed.CheckedChanged
        ' If the Used radio button is checked, then
        ' the user has selected a used car loan.
        If radUsed.Checked = True Then
            dblAnnualRate = USED_RATE
            txtAnnualRate.Text = USED_RATE.ToString("p")
        End If
    End Sub
End Class
